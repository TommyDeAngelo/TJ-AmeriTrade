@echo off
title TJ AmeriTrade V6
echo.
echo ==========================================
echo          TJ AMERITRADE V6
echo ==========================================
echo.
echo Installing/updating required packages...
python -m pip install -r requirements.txt
echo.
echo Launching TJ AmeriTrade...
python -m streamlit run app.py
pause
