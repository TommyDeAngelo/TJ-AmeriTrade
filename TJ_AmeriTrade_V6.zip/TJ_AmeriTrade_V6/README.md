
# TJ AmeriTrade V6

## V5 UX upgrades

### Sidebar watchlist buttons
Watchlist tickers are now proper navigation buttons rather than plain links.

Click a ticker in the left sidebar and TJ AmeriTrade immediately loads that stock into Analyzer.

### Type-ahead ticker search
Analyzer now uses a searchable type-ahead selector.

Examples:
- Type `MET` → META — Meta Platforms
- Type `MIC` → Microsoft / Micron
- Type a company name such as `Palantir`
- The selector filters results as you type

On modern Streamlit versions you can also enter a new ticker not already in the suggestion list.

## Existing V4 features retained
- Company logos
- TJ Rating
- Datum tracking
- Watchlist
- Top TJ Buys scanner
- Performance vs SPY
- 1M / 3M / 6M / YTD / 1Y relative performance
- Normalized stock vs SPY chart
- Performance Compare
- Internal Analyze links

## Windows
Double-click `run_windows.bat`.


## V6 cleanup
- Removed sidebar watchlist delete X buttons
- Watchlist ticker buttons now use the full row
- Removed the `vs SPY` bar from the main TJ Rating breakdown
- SPY relative-performance cards and charts remain available below Analyzer
- Relative Strength vs SPY still contributes 5% to the TJ Rating model; it is simply no longer shown as a fifth core pillar
