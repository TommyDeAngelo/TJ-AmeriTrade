
import json
import math
from datetime import date, datetime, timedelta
from pathlib import Path
from urllib.parse import urlparse

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import yfinance as yf

st.set_page_config(
    page_title="TJ AmeriTrade",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
WATCHLIST_FILE = DATA_DIR / "watchlist.json"
DATUM_FILE = DATA_DIR / "datum_points.json"

COMPANY_NAMES = {
    "AAPL":"Apple Inc.","MSFT":"Microsoft Corporation","NVDA":"NVIDIA Corporation",
    "META":"Meta Platforms, Inc.","GOOGL":"Alphabet Inc.","AMZN":"Amazon.com, Inc.",
    "AVGO":"Broadcom Inc.","TSM":"Taiwan Semiconductor Manufacturing",
    "AMD":"Advanced Micro Devices, Inc.","MU":"Micron Technology, Inc.",
    "ORCL":"Oracle Corporation","CRM":"Salesforce, Inc.","ADBE":"Adobe Inc.",
    "NFLX":"Netflix, Inc.","NOW":"ServiceNow, Inc.","PLTR":"Palantir Technologies Inc.",
    "INTC":"Intel Corporation","QCOM":"QUALCOMM Incorporated","ARM":"Arm Holdings plc",
    "SMCI":"Super Micro Computer, Inc.","JPM":"JPMorgan Chase & Co.",
    "BAC":"Bank of America Corporation","GS":"The Goldman Sachs Group, Inc.",
    "MS":"Morgan Stanley","V":"Visa Inc.","MA":"Mastercard Incorporated",
    "AXP":"American Express Company","SCHW":"The Charles Schwab Corporation",
    "LLY":"Eli Lilly and Company","UNH":"UnitedHealth Group Incorporated",
    "ABBV":"AbbVie Inc.","MRK":"Merck & Co., Inc.","JNJ":"Johnson & Johnson",
    "TMO":"Thermo Fisher Scientific Inc.","ISRG":"Intuitive Surgical, Inc.",
    "WMT":"Walmart Inc.","COST":"Costco Wholesale Corporation",
    "HD":"The Home Depot, Inc.","LOW":"Lowe's Companies, Inc.","NKE":"NIKE, Inc.",
    "SBUX":"Starbucks Corporation","MCD":"McDonald's Corporation",
    "CAT":"Caterpillar Inc.","GE":"GE Aerospace","ETN":"Eaton Corporation plc",
    "DE":"Deere & Company","URI":"United Rentals, Inc.","FIX":"Comfort Systems USA, Inc.",
    "STRL":"Sterling Infrastructure, Inc.","XOM":"Exxon Mobil Corporation",
    "CVX":"Chevron Corporation","COP":"ConocoPhillips","SLB":"SLB",
    "NEE":"NextEra Energy, Inc.","CEG":"Constellation Energy Corporation",
    "VST":"Vistra Corp.","CCJ":"Cameco Corporation","SMR":"NuScale Power Corporation",
    "SOFI":"SoFi Technologies, Inc.","HOOD":"Robinhood Markets, Inc.",
    "COIN":"Coinbase Global, Inc.","HIMS":"Hims & Hers Health, Inc.",
    "CELH":"Celsius Holdings, Inc.","IREN":"IREN Limited","RKLB":"Rocket Lab Corporation",
    "SPY":"SPDR S&P 500 ETF Trust","QQQ":"Invesco QQQ Trust",
    "BRK-B":"Berkshire Hathaway Inc.","TSLA":"Tesla, Inc.","UBER":"Uber Technologies, Inc.",
    "ABNB":"Airbnb, Inc.","PANW":"Palo Alto Networks, Inc.","CRWD":"CrowdStrike Holdings, Inc.",
    "SHOP":"Shopify Inc.","SNOW":"Snowflake Inc.","APP":"AppLovin Corporation"
}

MARKET_UNIVERSE = list(COMPANY_NAMES.keys())
SEARCH_OPTIONS = [f"{ticker} — {name}" for ticker, name in COMPANY_NAMES.items()]

st.markdown("""
<style>
    :root {
        --bg: #0a0e13; --panel: #10171f; --border: #23303c;
        --text: #eef3f7; --muted: #8ea0b3; --accent: #5bbcff;
    }
    .stApp {
        background:
            radial-gradient(circle at 15% -10%, rgba(34,75,109,.20), transparent 25%),
            linear-gradient(180deg,#090d12 0%,#0d131a 100%);
        color: var(--text);
    }
    [data-testid="stSidebar"] {
        background:#0a1016;
        border-right:1px solid var(--border);
    }
    .block-container { padding-top:1.35rem; padding-bottom:3rem; }

    .brand-wrap { padding:8px 0 18px 0; }
    .brand-main {
        font-size:35px; font-weight:900; line-height:1;
        letter-spacing:-1.2px;
    }
    .brand-main span { color:var(--accent); }
    .brand-sub {
        margin-top:8px; color:var(--muted); font-size:12px;
        letter-spacing:.08em; text-transform:uppercase;
    }

    .stock-head {
        display:flex; align-items:center; gap:18px;
        background:linear-gradient(145deg,#111a23,#0e151c);
        border:1px solid var(--border); border-radius:18px;
        padding:20px 22px; margin:8px 0 18px 0;
        box-shadow:0 16px 40px rgba(0,0,0,.18);
    }
    .stock-logo-wrap {
        width:58px; height:58px; border-radius:14px;
        background:#f4f7fa; display:flex; align-items:center;
        justify-content:center; overflow:hidden;
        border:1px solid #31404f; flex:0 0 auto;
    }
    .stock-logo { width:42px; height:42px; object-fit:contain; }
    .ticker-title {
        font-size:29px; font-weight:850; margin:0; letter-spacing:-.5px;
    }
    .ticker-title .company { color:#8799aa; font-weight:500; }
    .company-sub { color:var(--muted); font-size:13px; margin-top:4px; }

    .rating-card {
        text-align:center; min-height:258px; display:flex;
        flex-direction:column; justify-content:center; border-radius:20px;
        border:1px solid #2a4054;
        background:
            radial-gradient(circle at 50% 35%, rgba(60,147,211,.16), transparent 45%),
            linear-gradient(160deg,#111b25,#0c1218);
        box-shadow:0 14px 35px rgba(0,0,0,.20);
    }
    .rating-eyebrow {
        color:var(--muted); font-size:11px; text-transform:uppercase;
        letter-spacing:.18em; font-weight:700;
    }
    .rating-number {
        font-size:68px; font-weight:950; line-height:.95;
        margin:10px 0 8px 0; letter-spacing:-3px;
    }
    .rating-caption { font-size:18px; font-weight:800; letter-spacing:.03em; }

    div[data-testid="stMetric"] {
        background:linear-gradient(145deg,#111922,#10171f);
        border:1px solid var(--border); padding:14px 15px;
        border-radius:14px;
    }

    .datum-banner {
        background:linear-gradient(145deg,#121d27,#101820);
        border:1px solid #2c4154; border-radius:14px;
        padding:14px 16px; margin-top:10px;
    }
    .datum-title { font-weight:800; font-size:14px; }
    .datum-sub { color:var(--muted); margin-top:3px; font-size:12px; }

    .section-head {
        margin-top:22px; margin-bottom:10px;
        font-size:20px; font-weight:800; letter-spacing:-.3px;
    }
    .section-sub {
        color:var(--muted); font-size:12px;
        margin-top:-7px; margin-bottom:12px;
    }

    .stTabs [data-baseweb="tab-list"] {
        gap:4px; background:#0d141b;
        border:1px solid var(--border);
        padding:5px; border-radius:12px;
    }
    .stTabs [data-baseweb="tab"] {
        border-radius:8px; padding-left:18px; padding-right:18px;
    }

    /* Make sidebar ticker buttons feel like compact nav buttons */
    [data-testid="stSidebar"] .stButton > button {
        border-radius:10px;
        border:1px solid #293846;
        background:#101820;
        color:#eaf2f8;
        text-align:left;
        justify-content:flex-start;
        font-weight:700;
        min-height:38px;
    }
    [data-testid="stSidebar"] .stButton > button:hover {
        border-color:#4d91bd;
        background:#14212c;
        color:#ffffff;
    }

    .footer-note {
        color:#728699; font-size:11px;
        text-align:center; margin-top:25px;
    }
</style>
""", unsafe_allow_html=True)

def load_json(path, default):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default

def save_json(path, data):
    path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")

def get_watchlist():
    raw = load_json(WATCHLIST_FILE, [])
    return list(dict.fromkeys([str(x).upper() for x in raw if x]))

def save_watchlist(items):
    save_json(WATCHLIST_FILE, list(dict.fromkeys([str(x).upper() for x in items if x])))

def get_datums():
    raw = load_json(DATUM_FILE, {})
    return raw if isinstance(raw, dict) else {}

def save_datums(datums):
    save_json(DATUM_FILE, datums)

def safe_num(value):
    try:
        if value is None:
            return np.nan
        value = float(value)
        if math.isnan(value) or math.isinf(value):
            return np.nan
        return value
    except Exception:
        return np.nan

def clamp(v, lo=0.0, hi=10.0):
    if pd.isna(v): return np.nan
    return max(lo, min(hi, float(v)))

def linear_score(value, bad, good, inverse=False):
    value = safe_num(value)
    if pd.isna(value): return np.nan
    if inverse:
        if value <= good: return 10.0
        if value >= bad: return 0.0
        return 10*(bad-value)/(bad-good)
    if value <= bad: return 0.0
    if value >= good: return 10.0
    return 10*(value-bad)/(good-bad)

def weighted_average(items):
    vals = [(safe_num(s),w) for s,w in items if not pd.isna(safe_num(s))]
    if not vals: return np.nan
    total = sum(w for _,w in vals)
    return sum(s*w for s,w in vals)/total

def fmt_money(v):
    v = safe_num(v)
    if pd.isna(v): return "N/A"
    av=abs(v)
    if av>=1e12: return f"${v/1e12:.2f}T"
    if av>=1e9: return f"${v/1e9:.2f}B"
    if av>=1e6: return f"${v/1e6:.2f}M"
    return f"${v:,.0f}"

def fmt_pct(v, decimals=1):
    v=safe_num(v)
    return "N/A" if pd.isna(v) else f"{v*100:.{decimals}f}%"

def fmt_x(v, decimals=1):
    v=safe_num(v)
    return "N/A" if pd.isna(v) else f"{v:.{decimals}f}x"

def rating_label(score):
    if pd.isna(score): return "INSUFFICIENT DATA"
    if score>=9: return "TJ RATING"
    if score>=8: return "STRONG BUY"
    if score>=7: return "BUY"
    if score>=6: return "MODERATE BUY"
    if score>=5: return "HOLD"
    if score>=4: return "WEAK"
    return "AVOID"

def parse_search_value(value):
    if not value:
        return "META"
    return str(value).split("—")[0].strip().upper()

def ticker_link(ticker):
    return f"?ticker={ticker}"

def get_logo_url(website):
    if not website: return ""
    try:
        parsed=urlparse(website if "://" in website else "https://"+website)
        domain=parsed.netloc.replace("www.","")
        return f"https://www.google.com/s2/favicons?domain={domain}&sz=128" if domain else ""
    except Exception:
        return ""

@st.cache_data(ttl=900, show_spinner=False)
def get_stock_data(ticker):
    ticker=ticker.upper()
    tk=yf.Ticker(ticker)
    try: info=tk.info or {}
    except Exception: info={}

    hist=tk.history(period="2y",auto_adjust=True)
    if hist.empty:
        raise ValueError(f"No market data found for {ticker}")

    close=hist["Close"].dropna()
    price=safe_num(close.iloc[-1])

    def ret(days):
        if len(close)<=days: return np.nan
        return price/safe_num(close.iloc[-days-1])-1

    current_year=pd.Timestamp.now().year
    ytd=close[close.index.year==current_year]
    ytd_ret=price/safe_num(ytd.iloc[0])-1 if len(ytd)>=2 else np.nan

    sma50=safe_num(close.tail(50).mean()) if len(close)>=50 else np.nan
    sma200=safe_num(close.tail(200).mean()) if len(close)>=200 else np.nan

    d={
        "ticker":ticker,
        "name":info.get("longName") or info.get("shortName") or COMPANY_NAMES.get(ticker,ticker),
        "sector":info.get("sector","N/A"),
        "industry":info.get("industry","N/A"),
        "website":info.get("website",""),
        "logo_url":get_logo_url(info.get("website","")),
        "price":price,
        "market_cap":safe_num(info.get("marketCap")),
        "trailing_pe":safe_num(info.get("trailingPE")),
        "forward_pe":safe_num(info.get("forwardPE")),
        "peg":safe_num(info.get("pegRatio")),
        "ev_ebitda":safe_num(info.get("enterpriseToEbitda")),
        "cash":safe_num(info.get("totalCash")),
        "debt":safe_num(info.get("totalDebt")),
        "debt_to_equity":safe_num(info.get("debtToEquity")),
        "current_ratio":safe_num(info.get("currentRatio")),
        "free_cash_flow":safe_num(info.get("freeCashflow")),
        "revenue_growth":safe_num(info.get("revenueGrowth")),
        "earnings_growth":safe_num(info.get("earningsGrowth")),
        "earnings_quarterly_growth":safe_num(info.get("earningsQuarterlyGrowth")),
        "operating_margin":safe_num(info.get("operatingMargins")),
        "profit_margin":safe_num(info.get("profitMargins")),
        "return_1m":ret(21),"return_3m":ret(63),"return_6m":ret(126),
        "return_ytd":ytd_ret,"return_1y":ret(252),
        "sma50":sma50,"sma200":sma200,
        "history":hist.reset_index(),
    }
    d["net_cash"]=d["cash"]-d["debt"] if not pd.isna(d["cash"]) and not pd.isna(d["debt"]) else np.nan
    return d

@st.cache_data(ttl=900, show_spinner=False)
def get_relative_returns(ticker):
    raw=yf.download([ticker,"SPY"],period="2y",auto_adjust=True,progress=False)["Close"]
    if raw.empty or isinstance(raw,pd.Series): return {}
    raw=raw.dropna(how="all")
    out={}
    for label,days in {"1M":21,"3M":63,"6M":126,"1Y":252}.items():
        vals={}
        for sym in [ticker,"SPY"]:
            if sym not in raw.columns:
                vals[sym]=np.nan
                continue
            s=raw[sym].dropna()
            vals[sym]=s.iloc[-1]/s.iloc[-days-1]-1 if len(s)>days else np.nan
        out[label]=vals

    vals={}
    current_year=pd.Timestamp.now().year
    for sym in [ticker,"SPY"]:
        if sym not in raw.columns:
            vals[sym]=np.nan
            continue
        s=raw[sym].dropna()
        y=s[s.index.year==current_year]
        vals[sym]=y.iloc[-1]/y.iloc[0]-1 if len(y)>=2 else np.nan
    out["YTD"]=vals
    return out

def score_stock(d,relative=None):
    valuation=weighted_average([
        (linear_score(d["trailing_pe"],45,10,True),.20),
        (linear_score(d["forward_pe"],40,9,True),.45),
        (linear_score(d["peg"],3,.7,True),.20),
        (linear_score(d["ev_ebitda"],30,7,True),.15)
    ])

    mc=d["market_cap"]
    nc_pct=d["net_cash"]/mc if not pd.isna(d["net_cash"]) and not pd.isna(mc) and mc>0 else np.nan
    de=d["debt_to_equity"]
    if not pd.isna(de): de/=100.0
    fcf_yield=d["free_cash_flow"]/mc if not pd.isna(d["free_cash_flow"]) and not pd.isna(mc) and mc>0 else np.nan

    financial=weighted_average([
        (linear_score(nc_pct,-.25,.15),.30),
        (linear_score(d["current_ratio"],.7,2),.15),
        (linear_score(de,2,.2,True),.20),
        (linear_score(fcf_yield,0,.08),.35)
    ])

    growth=weighted_average([
        (linear_score(d["revenue_growth"],-.05,.30),.35),
        (linear_score(d["earnings_growth"],-.10,.35),.35),
        (linear_score(d["earnings_quarterly_growth"],-.15,.40),.15),
        (linear_score(d["operating_margin"],0,.35),.15)
    ])

    momentum=weighted_average([
        (linear_score(d["return_1m"],-.15,.20),.10),
        (linear_score(d["return_3m"],-.25,.35),.20),
        (linear_score(d["return_6m"],-.35,.60),.25),
        (linear_score(d["return_1y"],-.45,1),.25),
        (linear_score(d["price"]/d["sma50"]-1,-.12,.12) if not pd.isna(d["sma50"]) and d["sma50"]>0 else np.nan,.10),
        (linear_score(d["price"]/d["sma200"]-1,-.20,.25) if not pd.isna(d["sma200"]) and d["sma200"]>0 else np.nan,.10)
    ])

    alpha_scores=[]
    if relative:
        for label,w in [("1M",.10),("3M",.20),("6M",.30),("1Y",.40)]:
            vals=relative.get(label,{})
            sr,spy=vals.get(d["ticker"],np.nan),vals.get("SPY",np.nan)
            if not pd.isna(sr) and not pd.isna(spy):
                alpha_scores.append((linear_score(sr-spy,-.20,.35),w))
    relative_strength=weighted_average(alpha_scores)

    overall=weighted_average([
        (valuation,.30),(financial,.25),(growth,.25),(momentum,.15),(relative_strength,.05)
    ])
    return {
        "overall":clamp(overall),"valuation":clamp(valuation),
        "financial":clamp(financial),"growth":clamp(growth),
        "momentum":clamp(momentum),"relative_strength":clamp(relative_strength)
    }

@st.cache_data(ttl=1800, show_spinner=False)
def scan_market(universe):
    rows=[]
    for ticker in universe:
        if ticker in ["SPY","QQQ"]:
            continue
        try:
            d=get_stock_data(ticker)
            rel=get_relative_returns(ticker)
            s=score_stock(d,rel)
            if not pd.isna(s["overall"]):
                rows.append({
                    "Ticker":ticker,"Company":d["name"],"Sector":d["sector"],
                    "Price":d["price"],"TJ Rating":s["overall"],
                    "Signal":rating_label(s["overall"]),
                    "Forward P/E":d["forward_pe"],
                    "Revenue Growth":d["revenue_growth"]*100 if not pd.isna(d["revenue_growth"]) else np.nan,
                    "Relative Strength":s["relative_strength"],
                    "6M %":d["return_6m"]*100 if not pd.isna(d["return_6m"]) else np.nan,
                    "Analyze":ticker_link(ticker)
                })
        except Exception:
            continue
    if not rows: return pd.DataFrame()
    return pd.DataFrame(rows).sort_values("TJ Rating",ascending=False).reset_index(drop=True)

@st.cache_data(ttl=900, show_spinner=False)
def get_compare_prices(tickers,start,end):
    raw=yf.download(tickers=tickers,start=start,end=end+timedelta(days=1),
                    auto_adjust=True,progress=False,group_by="column")
    if raw.empty: return pd.DataFrame()
    if len(tickers)==1:
        return raw[["Close"]].rename(columns={"Close":tickers[0]}).dropna(how="all")
    return raw["Close"].dropna(how="all")

query_ticker=st.query_params.get("ticker")
if query_ticker:
    st.session_state["selected_ticker"]=str(query_ticker).upper()

# Sidebar
st.sidebar.markdown("## TJ AmeriTrade")
st.sidebar.caption("Research terminal")

watchlist=get_watchlist()
new_watch=st.sidebar.text_input("Add ticker",placeholder="META").strip().upper()
if st.sidebar.button("Add to Watchlist",use_container_width=True,key="add_watch"):
    if new_watch and new_watch not in watchlist:
        watchlist.append(new_watch)
        save_watchlist(watchlist)
    st.rerun()

if watchlist:
    st.sidebar.markdown("### Watchlist")
    for w in watchlist:
        if st.sidebar.button(w,key=f"watch_{w}",use_container_width=True):
            st.session_state["selected_ticker"]=w
            st.query_params["ticker"]=w
            st.rerun()

st.sidebar.divider()
st.sidebar.caption("TJ Rating is a research signal, not investment advice.")

st.markdown("""
<div class="brand-wrap">
  <div class="brand-main">TJ <span>AmeriTrade</span></div>
  <div class="brand-sub">Market intelligence • valuation • growth • momentum • relative strength</div>
</div>
""",unsafe_allow_html=True)

tabs=st.tabs(["Analyzer","Watchlist","Top TJ Buys","Performance Compare"])

with tabs[0]:
    default_ticker=st.session_state.get("selected_ticker","META")
    default_option=f"{default_ticker} — {COMPANY_NAMES.get(default_ticker, default_ticker)}"
    options=[default_option]+[x for x in SEARCH_OPTIONS if not x.startswith(default_ticker+" —")]

    c1,c2=st.columns([5,1])
    with c1:
        try:
            search_value=st.selectbox(
                "Search ticker",
                options=options,
                index=0,
                key="ticker_search",
                accept_new_options=True,
                placeholder="Type a ticker or company name..."
            )
        except TypeError:
            # Compatibility fallback for older Streamlit installs
            search_value=st.selectbox(
                "Search ticker",
                options=options,
                index=0,
                key="ticker_search",
                placeholder="Type a ticker or company name..."
            )

        ticker=parse_search_value(search_value)
    with c2:
        st.write("")
        st.write("")
        if st.button("Analyze",type="primary",use_container_width=True):
            st.session_state["selected_ticker"]=ticker
            st.query_params["ticker"]=ticker
            st.rerun()

    if ticker:
        try:
            with st.spinner(f"Analyzing {ticker}..."):
                d=get_stock_data(ticker)
                relative=get_relative_returns(ticker)
                s=score_stock(d,relative)

            logo_html=""
            if d["logo_url"]:
                logo_html=f'<div class="stock-logo-wrap"><img class="stock-logo" src="{d["logo_url"]}"></div>'

            st.markdown(f"""
            <div class="stock-head">
              {logo_html}
              <div>
                <div class="ticker-title">{d['ticker']} <span class="company">| {d['name']}</span></div>
                <div class="company-sub">{d['sector']} • {d['industry']}</div>
              </div>
            </div>
            """,unsafe_allow_html=True)

            m1,m2,m3,m4,m5=st.columns(5)
            m1.metric("Price",f"${d['price']:,.2f}")
            m2.metric("Forward P/E",fmt_x(d["forward_pe"]))
            m3.metric("Net Cash",fmt_money(d["net_cash"]))
            m4.metric("Revenue Growth",fmt_pct(d["revenue_growth"]))
            m5.metric("1Y Return",fmt_pct(d["return_1y"]))

            left,right=st.columns([1,2])
            with left:
                score=s["overall"]
                st.markdown(f"""
                <div class="rating-card">
                  <div class="rating-eyebrow">TJ Rating</div>
                  <div class="rating-number">{'N/A' if pd.isna(score) else f'{score:.1f}'}</div>
                  <div class="rating-caption">{rating_label(score)}</div>
                </div>
                """,unsafe_allow_html=True)

                datums=get_datums()
                if ticker in datums:
                    datum=datums[ticker]
                    datum_price=float(datum["price"])
                    chg=d["price"]/datum_price-1
                    st.markdown(f"""
                    <div class="datum-banner">
                      <div class="datum-title">Datum active • ${datum_price:,.2f}</div>
                      <div class="datum-sub">{datum['timestamp']} • Change since datum: {chg*100:+.2f}%</div>
                    </div>
                    """,unsafe_allow_html=True)
                    if st.button("Reset Datum",use_container_width=True):
                        datums[ticker]={"price":d["price"],"timestamp":datetime.now().strftime("%Y-%m-%d %H:%M")}
                        save_datums(datums)
                        st.rerun()
                else:
                    if st.button("Drop Datum at Current Price",type="primary",use_container_width=True):
                        datums[ticker]={"price":d["price"],"timestamp":datetime.now().strftime("%Y-%m-%d %H:%M")}
                        save_datums(datums)
                        if ticker not in get_watchlist():
                            wl=get_watchlist(); wl.append(ticker); save_watchlist(wl)
                        st.rerun()

            with right:
                labels=["Valuation","Financial Quality","Growth","Momentum"]
                vals=[s["valuation"],s["financial"],s["growth"],s["momentum"]]
                fig=go.Figure(go.Bar(
                    x=[0 if pd.isna(v) else v for v in vals],
                    y=labels,orientation="h",
                    text=["N/A" if pd.isna(v) else f"{v:.1f}" for v in vals],
                    textposition="auto"
                ))
                fig.update_layout(
                    height=280,margin=dict(l=5,r=5,t=5,b=5),
                    xaxis=dict(range=[0,10],gridcolor="#25313c",zeroline=False),
                    yaxis=dict(autorange="reversed"),
                    paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",
                    font=dict(color="#e8eef4"),showlegend=False
                )
                st.plotly_chart(fig,use_container_width=True)

            st.markdown('<div class="section-head">Performance vs SPY</div>',unsafe_allow_html=True)
            st.markdown('<div class="section-sub">Stock return and excess return relative to the S&P 500 ETF.</div>',unsafe_allow_html=True)
            perf_cols=st.columns(5)
            for col,label in zip(perf_cols,["1M","3M","6M","YTD","1Y"]):
                vals=relative.get(label,{})
                stock_ret=vals.get(ticker,np.nan)
                spy_ret=vals.get("SPY",np.nan)
                alpha=stock_ret-spy_ret if not pd.isna(stock_ret) and not pd.isna(spy_ret) else np.nan
                with col:
                    st.metric(label,
                              "N/A" if pd.isna(stock_ret) else f"{stock_ret*100:+.1f}%",
                              None if pd.isna(alpha) else f"{alpha*100:+.1f}% vs SPY")

            raw=yf.download([ticker,"SPY"],period="1y",auto_adjust=True,progress=False)["Close"].dropna(how="all")
            if not raw.empty and ticker in raw.columns and "SPY" in raw.columns:
                norm=pd.DataFrame(index=raw.index)
                for sym in [ticker,"SPY"]:
                    series=raw[sym].dropna()
                    if len(series)>1:
                        norm[sym]=(raw[sym]/series.iloc[0]-1)*100
                fig_rel=go.Figure()
                for sym in [ticker,"SPY"]:
                    if sym in norm:
                        fig_rel.add_trace(go.Scatter(x=norm.index,y=norm[sym],mode="lines",name=sym,line=dict(width=2)))
                fig_rel.add_hline(y=0,line_dash="dash")
                fig_rel.update_layout(
                    title=f"{ticker} vs SPY — 1 Year Normalized Return",
                    height=390,hovermode="x unified",
                    paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",
                    font=dict(color="#e8eef4"),
                    xaxis=dict(gridcolor="#25313c"),
                    yaxis=dict(gridcolor="#25313c",title="Return %")
                )
                st.plotly_chart(fig_rel,use_container_width=True)

            hist=d["history"].copy()
            fig2=go.Figure()
            fig2.add_trace(go.Scatter(x=hist["Date"],y=hist["Close"],mode="lines",name=ticker,line=dict(width=2)))
            datums=get_datums()
            if ticker in datums:
                datum=datums[ticker]
                datum_price=float(datum["price"])
                datum_time=pd.to_datetime(datum["timestamp"])
                fig2.add_hline(y=datum_price,line_dash="dot",
                               annotation_text=f"Datum ${datum_price:,.2f}",
                               annotation_position="top left")
                fig2.add_trace(go.Scatter(x=[datum_time],y=[datum_price],mode="markers",
                                          marker=dict(size=11,symbol="diamond"),name="Datum"))
            fig2.update_layout(
                title=f"{ticker} Price History",height=420,hovermode="x unified",
                paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",
                font=dict(color="#e8eef4"),
                xaxis=dict(gridcolor="#25313c"),
                yaxis=dict(gridcolor="#25313c",title="Price"),
                legend=dict(orientation="h")
            )
            st.plotly_chart(fig2,use_container_width=True)

            st.markdown('<div class="section-head">Fundamentals</div>',unsafe_allow_html=True)
            metrics=pd.DataFrame([
                ["Market Cap",fmt_money(d["market_cap"])],
                ["Trailing P/E",fmt_x(d["trailing_pe"])],
                ["Forward P/E",fmt_x(d["forward_pe"])],
                ["PEG",fmt_x(d["peg"])],
                ["EV / EBITDA",fmt_x(d["ev_ebitda"])],
                ["Cash",fmt_money(d["cash"])],
                ["Debt",fmt_money(d["debt"])],
                ["Net Cash",fmt_money(d["net_cash"])],
                ["Free Cash Flow",fmt_money(d["free_cash_flow"])],
                ["Revenue Growth",fmt_pct(d["revenue_growth"])],
                ["Earnings Growth",fmt_pct(d["earnings_growth"])],
                ["Operating Margin",fmt_pct(d["operating_margin"])],
                ["Profit Margin",fmt_pct(d["profit_margin"])],
                ["1M Return",fmt_pct(d["return_1m"])],
                ["3M Return",fmt_pct(d["return_3m"])],
                ["6M Return",fmt_pct(d["return_6m"])],
                ["YTD Return",fmt_pct(d["return_ytd"])],
                ["1Y Return",fmt_pct(d["return_1y"])],
            ],columns=["Metric","Value"])
            st.dataframe(metrics,use_container_width=True,hide_index=True)

            with st.expander("How the TJ Rating is weighted"):
                st.markdown("""
                **TJ Rating**
                - Valuation — **30%**
                - Financial Quality — **25%**
                - Growth — **25%**
                - Momentum — **15%**
                - Relative Strength vs SPY — **5%**

                Forward P/E carries the most weight inside valuation, while free-cash-flow yield carries the most weight inside financial quality. Relative strength is kept small so market momentum can confirm a thesis without overpowering fundamentals.
                """)
        except Exception as e:
            st.error(f"Could not analyze {ticker}: {e}")

with tabs[1]:
    st.markdown("## Watchlist")
    st.caption("Quick-access names with TJ signals and performance since your datum.")
    watchlist=get_watchlist()
    datums=get_datums()

    if not watchlist:
        st.info("Your watchlist is empty. Add a ticker from the sidebar or drop a datum from Analyzer.")
    else:
        rows=[]
        for w in watchlist:
            try:
                d=get_stock_data(w); rel=get_relative_returns(w); s=score_stock(d,rel)
                datum=datums.get(w)
                datum_price=float(datum["price"]) if datum else np.nan
                since=(d["price"]/datum_price-1)*100 if datum and datum_price>0 else np.nan
                rows.append({
                    "Ticker":w,"Analyze":ticker_link(w),"Price":d["price"],
                    "TJ Rating":s["overall"],"Signal":rating_label(s["overall"]),
                    "Forward P/E":d["forward_pe"],"vs SPY":s["relative_strength"],
                    "Datum":datum_price,"Since Datum %":since
                })
            except Exception:
                rows.append({"Ticker":w,"Analyze":ticker_link(w)})

        df=pd.DataFrame(rows).sort_values("TJ Rating",ascending=False,na_position="last")
        st.dataframe(
            df,
            column_config={
                "Analyze":st.column_config.LinkColumn("Open",display_text="Analyze →"),
                "Price":st.column_config.NumberColumn("Price",format="$%.2f"),
                "TJ Rating":st.column_config.NumberColumn("TJ Rating",format="%.1f"),
                "Forward P/E":st.column_config.NumberColumn("Forward P/E",format="%.1fx"),
                "vs SPY":st.column_config.NumberColumn("vs SPY Score",format="%.1f"),
                "Datum":st.column_config.NumberColumn("Datum",format="$%.2f"),
                "Since Datum %":st.column_config.NumberColumn("Since Datum %",format="%+.2f%%")
            },
            use_container_width=True,hide_index=True
        )

with tabs[2]:
    st.markdown("## Top TJ Buys")
    st.caption("Model-ranked opportunities from the current market scan. Separate from your personal watchlist.")

    c1,c2,c3=st.columns([2,2,1])
    with c1:
        min_rating=st.slider("Minimum TJ Rating",5.0,10.0,7.0,.1)
    with c2:
        max_results=st.slider("Number of results",5,25,10,1)
    with c3:
        st.write(""); st.write("")
        if st.button("Refresh Scan",use_container_width=True):
            scan_market.clear()

    with st.spinner("Scanning market universe and calculating TJ Ratings..."):
        scan=scan_market(tuple(MARKET_UNIVERSE))

    if scan.empty:
        st.warning("No scan results available right now.")
    else:
        filt=scan[scan["TJ Rating"]>=min_rating].head(max_results).copy()
        if filt.empty:
            st.info("No stocks currently meet that minimum TJ Rating.")
        else:
            top=filt.iloc[0]
            a,b,c,d=st.columns(4)
            a.metric("Top Rated",top["Ticker"],f"{top['TJ Rating']:.1f}/10")
            b.metric("Qualifying Stocks",len(filt))
            c.metric("Median TJ Rating",f"{filt['TJ Rating'].median():.1f}")
            d.metric("Universe Size",len(MARKET_UNIVERSE))
            display=filt.copy()
            display.insert(0,"Rank",range(1,len(display)+1))
            st.dataframe(
                display,
                column_config={
                    "Analyze":st.column_config.LinkColumn("Open",display_text="Analyze →"),
                    "Price":st.column_config.NumberColumn("Price",format="$%.2f"),
                    "TJ Rating":st.column_config.NumberColumn("TJ Rating",format="%.1f"),
                    "Forward P/E":st.column_config.NumberColumn("Forward P/E",format="%.1fx"),
                    "Revenue Growth":st.column_config.NumberColumn("Revenue Growth",format="%+.1f%%"),
                    "Relative Strength":st.column_config.NumberColumn("vs SPY Score",format="%.1f"),
                    "6M %":st.column_config.NumberColumn("6M Return",format="%+.1f%%")
                },
                use_container_width=True,hide_index=True
            )

with tabs[3]:
    st.markdown("## Performance Compare")
    tickers_text=st.text_input("Tickers",value="META, GOOGL, MU, NVDA, SPY")
    presets=["1M","3M","6M","YTD","1Y","3Y","5Y","Custom"]
    preset=st.radio("Time interval",presets,horizontal=True,index=4)
    today=date.today()

    if preset=="1M": start=today-timedelta(days=31)
    elif preset=="3M": start=today-timedelta(days=93)
    elif preset=="6M": start=today-timedelta(days=186)
    elif preset=="YTD": start=date(today.year,1,1)
    elif preset=="1Y": start=today-timedelta(days=365)
    elif preset=="3Y": start=today-timedelta(days=365*3)
    elif preset=="5Y": start=today-timedelta(days=365*5)
    else:
        x1,x2=st.columns(2)
        with x1: start=st.date_input("Start date",today-timedelta(days=365),key="cmp_start")
        with x2: today=st.date_input("End date",today,key="cmp_end")

    tickers=list(dict.fromkeys([t.strip().upper() for t in tickers_text.split(",") if t.strip()]))[:10]

    if tickers:
        try:
            prices=get_compare_prices(tickers,start,today)
            valid=[c for c in tickers if c in prices.columns and prices[c].dropna().shape[0]>=2]
            prices=prices[valid]
            if prices.empty:
                st.warning("No usable price data.")
            else:
                normalized=pd.DataFrame(index=prices.index); ending={}
                for t in prices.columns:
                    srs=prices[t].dropna(); first=srs.iloc[0]
                    normalized[t]=(prices[t]/first-1)*100
                    ending[t]=(srs.iloc[-1]/first-1)*100

                fig=go.Figure()
                for t in normalized.columns:
                    fig.add_trace(go.Scatter(x=normalized.index,y=normalized[t],mode="lines",name=t,line=dict(width=2)))
                fig.add_hline(y=0,line_dash="dash")
                fig.update_layout(
                    height=550,hovermode="x unified",title="Normalized Return",
                    paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",
                    font=dict(color="#e8eef4"),
                    xaxis=dict(gridcolor="#25313c"),
                    yaxis=dict(gridcolor="#25313c",title="Return %")
                )
                st.plotly_chart(fig,use_container_width=True)

                rank=pd.DataFrame(sorted(ending.items(),key=lambda x:x[1],reverse=True),columns=["Ticker","Return %"])
                rank["Return %"]=rank["Return %"].round(2)
                rank["Analyze"]=rank["Ticker"].map(ticker_link)

                c1,c2,c3,c4=st.columns(4)
                c1.metric("Best Performer",rank.iloc[0]["Ticker"],f"{rank.iloc[0]['Return %']:+.2f}%")
                c2.metric("Worst Performer",rank.iloc[-1]["Ticker"],f"{rank.iloc[-1]['Return %']:+.2f}%")
                c3.metric("Average Return",f"{rank['Return %'].mean():+.2f}%")
                c4.metric("Compared",len(rank))

                st.dataframe(
                    rank,
                    column_config={
                        "Analyze":st.column_config.LinkColumn("Open",display_text="Analyze →"),
                        "Return %":st.column_config.NumberColumn("Return %",format="%+.2f%%")
                    },
                    use_container_width=True,hide_index=True
                )
        except Exception as e:
            st.error(f"Comparison failed: {e}")

st.markdown(
    '<div class="footer-note">TJ AmeriTrade • Proprietary research interface • For research and education only</div>',
    unsafe_allow_html=True
)
